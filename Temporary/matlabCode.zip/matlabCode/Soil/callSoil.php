<?php
echo exec("python callToMatlabSoil.py");
?>