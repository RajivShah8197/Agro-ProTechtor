<?php
echo exec("python hello.py");
?>