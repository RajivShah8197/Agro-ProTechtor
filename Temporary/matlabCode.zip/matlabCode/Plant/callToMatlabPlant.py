import matlab.engine, time
eng = matlab.engine.start_matlab()
eng.DetectDisease_GUI(nargout=0)
time.sleep(60)
