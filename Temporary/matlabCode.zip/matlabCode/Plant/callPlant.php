<?php
echo exec("python callToMatlabPlant.py");
?>