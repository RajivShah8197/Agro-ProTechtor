<?php
while(true){
    if(!exec("python callToMatlabPlant.py"));

}
?>